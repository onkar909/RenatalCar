# Basic Java Car Rental System

This is our 2nd year university project - first project that has user interface and this project was last updated on Oct 2013.

## Getting Started

will update soon as i finished upload the youtube tutorial for installing and how to run java program.

